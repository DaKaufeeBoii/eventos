import { model } from "@/lib/gemini";

export async function POST(req: Request) {
    try {
        const body = await req.json();

        const {
            eventType,
            audience,
            scale,
        } = body;

        const prompt = `
You are an event sponsorship expert.

Suggest:
1. Best sponsor categories
2. Example sponsor companies
3. Outreach strategy

Event Type: ${eventType}
Audience: ${audience}
Scale: ${scale}

Keep response concise and startup-friendly.
`;

        const result =
            await model.generateContent(prompt);

        const response =
            result.response.text();

        return Response.json({
            success: true,
            data: response,
        });
    } catch (error) {
        return Response.json({
            success: false,
            error: "AI generation failed",
        });
    }
}