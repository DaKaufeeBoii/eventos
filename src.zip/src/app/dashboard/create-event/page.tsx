"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createEvent } from "@/lib/events";

export default function CreateEventPage() {
    const router = useRouter();

    const [title, setTitle] = useState("");
    const [description, setDescription] =
        useState("");

    const [location, setLocation] =
        useState("");

    const [eventDate, setEventDate] =
        useState("");

    const [loading, setLoading] =
        useState(false);

    async function handleCreateEvent(
        e: React.FormEvent
    ) {
        e.preventDefault();

        setLoading(true);

        const { error } = await createEvent({
            title,
            description,
            location,
            event_date: eventDate,
        });

        setLoading(false);

        if (error) {
            alert(error.message);
            return;
        }

        alert("Event created!");

        router.push("/dashboard/events");
    }

    return (
        <main className="min-h-screen bg-black text-white p-8">
            <div className="max-w-2xl mx-auto rounded-2xl border border-white/10 bg-white/5 p-8">
                <h1 className="text-4xl font-bold mb-6">
                    Create Event
                </h1>

                <form
                    onSubmit={handleCreateEvent}
                    className="space-y-4"
                >
                    <input
                        type="text"
                        placeholder="Event Title"
                        value={title}
                        onChange={(e) =>
                            setTitle(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3"
                    />

                    <textarea
                        placeholder="Description"
                        value={description}
                        onChange={(e) =>
                            setDescription(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3 h-32"
                    />

                    <input
                        type="text"
                        placeholder="Location"
                        value={location}
                        onChange={(e) =>
                            setLocation(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3"
                    />

                    <input
                        type="datetime-local"
                        value={eventDate}
                        onChange={(e) =>
                            setEventDate(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3"
                    />

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full rounded-xl bg-white text-black py-3 font-semibold"
                    >
                        {loading
                            ? "Creating..."
                            : "Create Event"}
                    </button>
                </form>
            </div>
        </main>
    );
}