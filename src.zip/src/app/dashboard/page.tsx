"use client";

import { signOut } from "@/lib/auth";

export default function DashboardPage() {
    async function handleLogout() {
        await signOut();

        window.location.href = "/login";
    }

    return (
        <main className="min-h-screen bg-black text-white p-8">
            <div className="flex items-center justify-between mb-8">
                <h1 className="text-4xl font-bold">
                    Dashboard
                </h1>

                <a
                    href="/dashboard/events"
                    className="px-4 py-2 rounded-xl bg-white text-black"
                >
                    View Events
                </a>

                <a
                    href="/dashboard/volunteers"
                    className="px-4 py-2 rounded-xl bg-white text-black"
                >
                    Volunteers
                </a>

                <a
                    href="/dashboard/ai-sponsor"
                    className="px-4 py-2 rounded-xl bg-white text-black"
                >
                    AI Sponsor Assistant
                </a>


                <button
                    onClick={handleLogout}
                    className="px-4 py-2 rounded-xl bg-white text-black"
                >
                    Logout
                </button>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
                    <h2 className="text-xl font-semibold">
                        Total Events
                    </h2>

                    <p className="text-5xl mt-4 font-bold">
                        12
                    </p>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
                    <h2 className="text-xl font-semibold">
                        Volunteers
                    </h2>

                    <p className="text-5xl mt-4 font-bold">
                        48
                    </p>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
                    <h2 className="text-xl font-semibold">
                        Participants
                    </h2>

                    <p className="text-5xl mt-4 font-bold">
                        312
                    </p>
                </div>
            </div>
        </main>
    );
}