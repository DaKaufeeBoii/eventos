"use client";

import { useEffect, useState } from "react";
import { getEvents } from "@/lib/events";
import { Event } from "@/types/event";

export default function EventsPage() {
    const [events, setEvents] = useState<
        Event[]
    >([]);

    useEffect(() => {
        async function fetchEvents() {
            const { data } = await getEvents();

            if (data) {
                setEvents(data);
            }
        }

        fetchEvents();
    }, []);

    return (
        <main className="min-h-screen bg-black text-white p-8">
            <div className="flex items-center justify-between mb-8">
                <h1 className="text-4xl font-bold">
                    Events
                </h1>

                <a
                    href="/dashboard/create-event"
                    className="px-4 py-2 rounded-xl bg-white text-black"
                >
                    Create Event
                </a>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {events.map((event) => (
                    <div
                        key={event.id}
                        className="rounded-2xl border border-white/10 bg-white/5 p-6"
                    >
                        <h2 className="text-2xl font-bold mb-2">
                            {event.title}
                        </h2>

                        <p className="text-zinc-400 mb-4">
                            {event.description}
                        </p>

                        <p className="text-sm">
                            📍 {event.location}
                        </p>

                        <p className="text-sm mt-2">
                            📅{" "}
                            {new Date(
                                event.event_date
                            ).toLocaleString()}
                        </p>
                    </div>
                ))}
            </div>
        </main>
    );
}