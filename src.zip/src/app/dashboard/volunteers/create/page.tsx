"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createVolunteer } from "@/lib/volunteers";

export default function CreateVolunteerPage() {
    const router = useRouter();

    const [name, setName] = useState("");
    const [email, setEmail] =
        useState("");

    const [skills, setSkills] =
        useState("");

    async function handleSubmit(
        e: React.FormEvent
    ) {
        e.preventDefault();

        const { error } =
            await createVolunteer({
                name,
                email,
                skills: skills
                    .split(",")
                    .map((s) => s.trim()),
            });

        if (error) {
            alert(error.message);
            return;
        }

        router.push(
            "/dashboard/volunteers"
        );
    }

    return (
        <main className="min-h-screen bg-black text-white p-8">
            <div className="max-w-xl mx-auto rounded-2xl border border-white/10 bg-white/5 p-8">
                <h1 className="text-4xl font-bold mb-6">
                    Add Volunteer
                </h1>

                <form
                    onSubmit={handleSubmit}
                    className="space-y-4"
                >
                    <input
                        type="text"
                        placeholder="Name"
                        value={name}
                        onChange={(e) =>
                            setName(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3"
                    />

                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) =>
                            setEmail(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3"
                    />

                    <input
                        type="text"
                        placeholder="Skills (comma separated)"
                        value={skills}
                        onChange={(e) =>
                            setSkills(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3"
                    />

                    <button
                        type="submit"
                        className="w-full rounded-xl bg-white text-black py-3 font-semibold"
                    >
                        Add Volunteer
                    </button>
                </form>
            </div>
        </main>
    );
}