"use client";

import { useEffect, useState } from "react";
import { getVolunteers } from "@/lib/volunteers";
import { Volunteer } from "@/types/volunteer";

export default function VolunteersPage() {
    const [volunteers, setVolunteers] =
        useState<Volunteer[]>([]);

    useEffect(() => {
        async function fetchVolunteers() {
            const { data } =
                await getVolunteers();

            if (data) {
                setVolunteers(data);
            }
        }

        fetchVolunteers();
    }, []);

    return (
        <main className="min-h-screen bg-black text-white p-8">
            <div className="flex items-center justify-between mb-8">
                <h1 className="text-4xl font-bold">
                    Volunteers
                </h1>

                <a
                    href="/dashboard/volunteers/create"
                    className="px-4 py-2 rounded-xl bg-white text-black"
                >
                    Add Volunteer
                </a>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {volunteers.map((volunteer) => (
                    <div
                        key={volunteer.id}
                        className="rounded-2xl border border-white/10 bg-white/5 p-6"
                    >
                        <div className="flex items-center justify-between">
                            <h2 className="text-2xl font-bold">
                                {volunteer.name}
                            </h2>

                            <span className="text-sm bg-white text-black px-3 py-1 rounded-full">
                                {volunteer.points} pts
                            </span>
                        </div>

                        <p className="text-zinc-400 mt-2">
                            {volunteer.email}
                        </p>

                        <div className="flex flex-wrap gap-2 mt-4">
                            {volunteer.skills?.map(
                                (skill) => (
                                    <span
                                        key={skill}
                                        className="text-xs px-2 py-1 rounded-full bg-zinc-800"
                                    >
                                        {skill}
                                    </span>
                                )
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </main>
    );
}