import Link from "next/link";

export default function HomePage() {
    return (
        <main className="min-h-screen bg-black text-white flex flex-col items-center justify-center gap-6">
            <h1 className="text-6xl font-bold tracking-tight">
                EventOS
            </h1>

            <p className="text-zinc-400 text-lg">
                AI-powered ecosystem for modern events
            </p>

            <div className="flex gap-4">
                <Link
                    href="/signup"
                    className="px-6 py-3 rounded-xl bg-white text-black font-medium hover:opacity-90 transition"
                >
                    Get Started
                </Link>

                <Link
                    href="/login"
                    className="px-6 py-3 rounded-xl border border-white/10 bg-white/5 backdrop-blur hover:bg-white/10 transition"
                >
                    Login
                </Link>
            </div>
        </main>
    );
}