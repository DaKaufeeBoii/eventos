"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "@/lib/auth";

export default function LoginPage() {
    const router = useRouter();

    const [email, setEmail] = useState("");
    const [password, setPassword] =
        useState("");

    const [loading, setLoading] =
        useState(false);

    async function handleLogin(
        e: React.FormEvent
    ) {
        e.preventDefault();

        setLoading(true);

        const { error } = await signIn(
            email,
            password
        );

        setLoading(false);

        if (error) {
            alert(error.message);
            return;
        }

        router.push("/dashboard");
    }

    return (
        <main className="min-h-screen flex items-center justify-center bg-black text-white">
            <div className="w-full max-w-md rounded-2xl border border-white/10 bg-white/5 p-8 backdrop-blur">
                <h1 className="text-3xl font-bold mb-2">
                    Welcome Back
                </h1>

                <p className="text-zinc-400 mb-6">
                    Login to continue to EventOS.
                </p>

                <form
                    onSubmit={handleLogin}
                    className="space-y-4"
                >
                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) =>
                            setEmail(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3 outline-none"
                    />

                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) =>
                            setPassword(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3 outline-none"
                    />

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full rounded-xl bg-white text-black py-3 font-semibold hover:opacity-90 transition"
                    >
                        {loading
                            ? "Logging in..."
                            : "Login"}
                    </button>
                </form>
            </div>
        </main>
    );
}