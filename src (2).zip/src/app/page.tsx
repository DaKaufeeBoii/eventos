import Link from "next/link";

export default function HomePage() {
    return (
        <main className="min-h-screen bg-black text-white overflow-hidden">

            <section className="relative flex flex-col items-center justify-center text-center px-6 py-32">

                <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 via-pink-500/10 to-transparent blur-3xl" />

                <h1 className="text-7xl md:text-8xl font-black tracking-tight relative z-10">
                    EventOS
                </h1>

                <p className="mt-6 text-zinc-400 text-xl max-w-2xl relative z-10">
                    AI-powered ecosystem for managing modern events,
                    volunteers, sponsors, and participants.
                </p>

                <div className="flex gap-4 mt-10 relative z-10">
                    <Link
                        href="/signup"
                        className="px-8 py-4 rounded-2xl bg-white text-black font-semibold hover:scale-105 transition"
                    >
                        Get Started
                    </Link>

                    <Link
                        href="/login"
                        className="px-8 py-4 rounded-2xl border border-white/10 bg-white/5 backdrop-blur hover:bg-white/10 transition"
                    >
                        Login
                    </Link>
                </div>
            </section>

            <section className="px-6 pb-32">

                <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">

                    <div className="rounded-3xl border border-white/10 bg-white/5 p-8 backdrop-blur">
                        <h2 className="text-2xl font-bold mb-4">
                            AI Sponsor Matching
                        </h2>

                        <p className="text-zinc-400">
                            Generate sponsorship opportunities instantly using AI.
                        </p>
                    </div>

                    <div className="rounded-3xl border border-white/10 bg-white/5 p-8 backdrop-blur">
                        <h2 className="text-2xl font-bold mb-4">
                            Volunteer Ecosystem
                        </h2>

                        <p className="text-zinc-400">
                            Manage volunteers, leaderboards, and tasks seamlessly.
                        </p>
                    </div>

                    <div className="rounded-3xl border border-white/10 bg-white/5 p-8 backdrop-blur">
                        <h2 className="text-2xl font-bold mb-4">
                            Smart Event Operations
                        </h2>

                        <p className="text-zinc-400">
                            Create events, track participants, and automate workflows.
                        </p>
                    </div>

                </div>

            </section>

        </main>
    );
}