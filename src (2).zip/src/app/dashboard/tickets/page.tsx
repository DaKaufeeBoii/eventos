"use client";

import QRCode from "react-qr-code";

export default function TicketsPage() {

    const ticketData = {
        attendee: "John Doe",
        event: "EventOS Hackathon",
        ticketId: "EVT-2026-001",
    };

    return (
        <main className="min-h-screen bg-black text-white flex items-center justify-center p-8">

            <div className="rounded-3xl border border-white/10 bg-white/5 p-10 text-center">

                <h1 className="text-4xl font-bold mb-6">
                    Event Ticket
                </h1>

                <div className="bg-white p-4 rounded-2xl inline-block">
                    <QRCode
                        value={JSON.stringify(ticketData)}
                        size={220}
                    />
                </div>

                <p className="mt-6 text-zinc-400">
                    Scan for secure event entry
                </p>

            </div>

        </main>
    );
}