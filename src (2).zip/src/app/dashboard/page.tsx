"use client";

import {
    BarChart,
    Bar,
    XAxis,
    Tooltip,
    ResponsiveContainer,
} from "recharts";

const data = [
    { name: "Jan", events: 4 },
    { name: "Feb", events: 7 },
    { name: "Mar", events: 12 },
    { name: "Apr", events: 9 },
];

export default function DashboardPage() {
    return (
        <main className="min-h-screen bg-black text-white p-8">

            <div className="flex items-center justify-between mb-10">

                <div>
                    <h1 className="text-5xl font-bold">
                        Dashboard
                    </h1>

                    <p className="text-zinc-400 mt-2">
                        Manage your entire event ecosystem.
                    </p>
                </div>

            </div>

            <div className="grid md:grid-cols-3 gap-6 mb-10">

                <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
                    <h2 className="text-zinc-400">
                        Total Events
                    </h2>

                    <p className="text-5xl font-black mt-4">
                        12
                    </p>
                </div>

                <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
                    <h2 className="text-zinc-400">
                        Volunteers
                    </h2>

                    <p className="text-5xl font-black mt-4">
                        48
                    </p>
                </div>

                <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
                    <h2 className="text-zinc-400">
                        Participants
                    </h2>

                    <p className="text-5xl font-black mt-4">
                        312
                    </p>
                </div>

            </div>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-8">

                <h2 className="text-2xl font-bold mb-6">
                    Event Analytics
                </h2>

                <div className="h-[300px]">

                    <ResponsiveContainer width="100%" height="100%">

                        <BarChart data={data}>

                            <XAxis dataKey="name" />

                            <Tooltip />

                            <Bar
                                dataKey="events"
                                radius={[10, 10, 0, 0]}
                            />

                        </BarChart>

                    </ResponsiveContainer>

                </div>

            </div>

        </main>
    );
}