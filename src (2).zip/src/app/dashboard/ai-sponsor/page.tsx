"use client";

import { useState } from "react";

export default function AISponsorPage() {
    const [eventType, setEventType] =
        useState("");

    const [audience, setAudience] =
        useState("");

    const [scale, setScale] =
        useState("");

    const [loading, setLoading] =
        useState(false);

    const [result, setResult] =
        useState("");

    async function generateSponsors(
        e: React.FormEvent
    ) {
        e.preventDefault();

        try {

            setLoading(true);
            setResult("");

            const response = await fetch(
                "/api/sponsor-ai",
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json",
                    },
                    body: JSON.stringify({
                        eventType,
                        audience,
                        scale,
                    }),
                }
            );

            const data = await response.json();

            if (data.success) {
                setResult(data.data);
            } else {
                setResult(data.error);
            }

        } catch (error: any) {

            setResult(
                error?.message ||
                "Something went wrong"
            );

        } finally {

            setLoading(false);

        }
    }

    return (
        <main className="min-h-screen bg-black text-white p-8">
            <div className="max-w-3xl mx-auto">
                <h1 className="text-5xl font-bold mb-2">
                    AI Sponsor Assistant
                </h1>

                <p className="text-zinc-400 mb-8">
                    Generate sponsorship ideas using AI.
                </p>

                <form
                    onSubmit={generateSponsors}
                    className="space-y-4 rounded-2xl border border-white/10 bg-white/5 p-6"
                >
                    <input
                        type="text"
                        placeholder="Event Type"
                        value={eventType}
                        onChange={(e) =>
                            setEventType(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3"
                    />

                    <input
                        type="text"
                        placeholder="Audience"
                        value={audience}
                        onChange={(e) =>
                            setAudience(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3"
                    />

                    <input
                        type="text"
                        placeholder="Expected Scale"
                        value={scale}
                        onChange={(e) =>
                            setScale(e.target.value)
                        }
                        className="w-full rounded-xl bg-zinc-900 border border-white/10 px-4 py-3"
                    />

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full rounded-xl bg-white text-black py-3 font-semibold"
                    >
                        {loading
                            ? "Generating..."
                            : "Generate Sponsors"}
                    </button>
                </form>

                {result && (
                    <div className="mt-8 rounded-2xl border border-white/10 bg-white/5 p-6 whitespace-pre-wrap">
                        {result}
                    </div>
                )}
            </div>
        </main>
    );
}